public class main {
    public static void Main(String[] args){
        System.out.println("Hello");
    }
}
